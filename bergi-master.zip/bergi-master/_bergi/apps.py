from django.apps import AppConfig

class config(AppConfig):
    name = "_bergi"
